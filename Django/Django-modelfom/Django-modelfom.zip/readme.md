# 현재 구현한 기능

1. 보안을 위해 암호키 분리

2. 하나의 포로젝트 내부에서 accounts와 articles 두가지 앱 생성

3. 회원 가입 기능

4. 로그인 기능 통합

5. 로그인 했을때만 동작하는 기능 구현(수정, 삭제)

6. 이미지 업로드 기능

7. 댓글 기능 (articles/comments)

8. 이미지 수정 기능 

9. 좋아요 기능

10. 팔로우 기능

11. "GET /serviceworker.js HTTP/1.1" 404
- 개발자도구-application-unregister





